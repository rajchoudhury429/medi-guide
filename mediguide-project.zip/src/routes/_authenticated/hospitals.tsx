import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { MapPin, Phone, Navigation, Star, Loader2, LocateFixed } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/hospitals")({
  head: () => ({
    meta: [
      { title: "Nearby hospitals & pharmacies — MediGuide AI" },
      { name: "description", content: "Find hospitals, clinics and pharmacies near you with distance, ratings, opening status, call and directions." },
      { property: "og:title", content: "Nearby hospitals & pharmacies — MediGuide AI" },
      { property: "og:description", content: "Hospitals, clinics and pharmacies near you with distance, ratings and directions." },
    ],
  }),
  component: HospitalsPage,
});

const KINDS = [
  { value: "all", label: "All" },
  { value: "hospital", label: "Hospitals" },
  { value: "clinic", label: "Clinics" },
  { value: "pharmacy", label: "Pharmacies" },
] as const;

type Coords = { lat: number; lng: number };

function distanceKm(a: Coords, b: Coords) {
  const toRad = (value: number) => (value * Math.PI) / 180;
  const R = 6371;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

function isOpenNow(open24h: boolean, opensAt: string | null, closesAt: string | null) {
  if (open24h) return true;
  if (!opensAt || !closesAt) return true;
  const now = new Date();
  const minutes = now.getHours() * 60 + now.getMinutes();
  const [oh, om] = opensAt.split(":").map(Number);
  const [ch, cm] = closesAt.split(":").map(Number);
  return minutes >= oh * 60 + om && minutes <= ch * 60 + cm;
}

function HospitalsPage() {
  const [coords, setCoords] = useState<Coords | null>(null);
  const [locating, setLocating] = useState(true);
  const [kind, setKind] = useState<string>("all");

  useEffect(() => {
    if (!("geolocation" in navigator)) {
      setLocating(false);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setCoords({ lat: position.coords.latitude, lng: position.coords.longitude });
        setLocating(false);
      },
      () => {
        setLocating(false);
      },
      { timeout: 8000 },
    );
  }, []);

  const { data, isLoading } = useQuery({
    queryKey: ["facilities"],
    queryFn: async () => {
      const { data: rows, error } = await supabase.from("facilities").select("*");
      if (error) throw error;
      return rows;
    },
  });

  const reference = coords ?? { lat: 28.6139, lng: 77.209 };

  const facilities = useMemo(() => {
    if (!data) return [];
    return data
      .filter((facility) => kind === "all" || facility.kind === kind)
      .map((facility) => ({
        ...facility,
        distance: distanceKm(reference, {
          lat: Number(facility.latitude),
          lng: Number(facility.longitude),
        }),
      }))
      .sort((a, b) => a.distance - b.distance);
  }, [data, kind, reference.lat, reference.lng]);

  const mapSrc = `https://www.openstreetmap.org/export/embed.html?bbox=${reference.lng - 0.08}%2C${reference.lat - 0.06}%2C${reference.lng + 0.08}%2C${reference.lat + 0.06}&layer=mapnik&marker=${reference.lat}%2C${reference.lng}`;

  function retryLocation() {
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setCoords({ lat: position.coords.latitude, lng: position.coords.longitude });
        setLocating(false);
        toast.success("Location updated");
      },
      () => {
        setLocating(false);
        toast.error("Location permission denied. Showing default area.");
      },
    );
  }

  return (
    <div>
      <PageHeader
        title="Care near you"
        subtitle={coords ? "Sorted by distance from your location" : "Using a default area — enable location for accurate distances"}
        action={
          <Button variant="ghost" size="icon" onClick={retryLocation} aria-label="Refresh location">
            {locating ? <Loader2 className="h-4 w-4 animate-spin" /> : <LocateFixed className="h-4 w-4" />}
          </Button>
        }
      />

      <div className="mx-5 overflow-hidden rounded-2xl shadow-card">
        <iframe
          title="Map of your area"
          src={mapSrc}
          className="h-52 w-full border-0"
          loading="lazy"
        />
      </div>

      <div className="no-scrollbar mt-4 flex gap-2 overflow-x-auto px-5">
        {KINDS.map((option) => (
          <button
            key={option.value}
            type="button"
            onClick={() => setKind(option.value)}
            className={cn(
              "shrink-0 rounded-full px-4 py-2 text-sm font-medium transition-colors",
              kind === option.value
                ? "bg-primary text-primary-foreground"
                : "bg-card text-muted-foreground shadow-card",
            )}
          >
            {option.label}
          </button>
        ))}
      </div>

      <ul className="mt-4 space-y-3 px-5 pb-6">
        {isLoading ? (
          <li className="flex justify-center py-8">
            <Loader2 className="h-5 w-5 animate-spin text-primary" />
          </li>
        ) : null}

        {facilities.map((facility) => {
          const open = isOpenNow(facility.open_24h, facility.opens_at, facility.closes_at);
          return (
            <li key={facility.id} className="rounded-2xl bg-card p-4 shadow-card">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h2 className="text-sm font-semibold text-foreground">{facility.name}</h2>
                  <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
                    <MapPin className="h-3.5 w-3.5" />
                    {facility.address}, {facility.city}
                  </p>
                  <div className="mt-2 flex flex-wrap items-center gap-2 text-xs">
                    <span className="flex items-center gap-1 rounded-full bg-secondary px-2 py-1 text-secondary-foreground">
                      <Star className="h-3 w-3 fill-current text-warning" />
                      {Number(facility.rating).toFixed(1)}
                    </span>
                    <span className="rounded-full bg-secondary px-2 py-1 text-secondary-foreground">
                      {facility.distance.toFixed(1)} km
                    </span>
                    <span
                      className={cn(
                        "rounded-full px-2 py-1 font-medium",
                        open ? "bg-accent-soft text-accent-foreground" : "bg-destructive/10 text-destructive",
                      )}
                    >
                      {facility.open_24h ? "Open 24h" : open ? "Open now" : "Closed"}
                    </span>
                    <span className="rounded-full bg-primary-soft px-2 py-1 capitalize text-primary">
                      {facility.kind}
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-2">
                <Button asChild variant="outline" size="sm">
                  <a href={`tel:${facility.phone ?? ""}`}>
                    <Phone className="h-4 w-4" />
                    Call
                  </a>
                </Button>
                <Button asChild size="sm">
                  <a
                    href={`https://www.google.com/maps/dir/?api=1&destination=${facility.latitude},${facility.longitude}`}
                    target="_blank"
                    rel="noreferrer"
                  >
                    <Navigation className="h-4 w-4" />
                    Directions
                  </a>
                </Button>
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

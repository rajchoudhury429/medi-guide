import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Send, Loader2, Sparkles, AlertTriangle, RotateCcw } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";
import { askSymptomAI } from "@/lib/ai.functions";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/lib/use-session";
import { AiMarkdown } from "@/components/AiMarkdown";
import { VoiceButton } from "@/components/VoiceButton";
import { PageHeader } from "@/components/AppShell";
import { Button } from "@/components/ui/button";

const searchSchema = z.object({ q: z.string().max(500).optional() });

export const Route = createFileRoute("/_authenticated/ai")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "AI symptom checker — MediGuide AI" },
      { name: "description", content: "Describe your symptoms in plain language and get structured, informational guidance with self-care advice and emergency warning signs." },
      { property: "og:title", content: "AI symptom checker — MediGuide AI" },
      { property: "og:description", content: "Structured, informational symptom guidance — never a diagnosis." },
    ],
  }),
  component: SymptomChecker,
});

type Message = { role: "user" | "assistant"; content: string };

const STARTERS = [
  "I have a headache and mild fever since yesterday",
  "Sore throat with dry cough for 3 days",
  "Stomach pain after meals this week",
];

function SymptomChecker() {
  const { q } = Route.useSearch();
  const { user } = useSession();
  const queryClient = useQueryClient();
  const ask = useServerFn(askSymptomAI);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const seededRef = useRef<string | undefined>(undefined);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, busy]);

  useEffect(() => {
    if (q && seededRef.current !== q) {
      seededRef.current = q;
      void send(q);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q]);

  async function send(text: string) {
    const value = text.trim();
    if (!value || busy) return;

    const nextMessages: Message[] = [...messages, { role: "user", content: value }];
    setMessages(nextMessages);
    setInput("");
    setBusy(true);

    try {
      const result = await ask({ data: { messages: nextMessages.slice(-20) } });
      setMessages([...nextMessages, { role: "assistant", content: result.text }]);

      if (user && nextMessages.filter((m) => m.role === "user").length === 1) {
        await supabase.from("symptom_checks").insert({
          user_id: user.id,
          symptoms: value.slice(0, 500),
          summary: result.text.slice(0, 2000),
        });
        queryClient.invalidateQueries({ queryKey: ["recent-checks", user.id] });
      }
    } catch (error) {
      setMessages(nextMessages);
      toast.error(error instanceof Error ? error.message : "Something went wrong.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <PageHeader
        title="AI symptom checker"
        subtitle="Describe how you feel — the assistant may ask follow-up questions."
        action={
          messages.length > 0 ? (
            <Button variant="ghost" size="icon" onClick={() => setMessages([])} aria-label="Start over">
              <RotateCcw className="h-4 w-4" />
            </Button>
          ) : null
        }
      />

      <div className="mx-5 flex items-start gap-2 rounded-2xl bg-warning-soft px-4 py-3 text-xs text-warning-foreground">
        <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
        <p>
          Informational guidance only — this is not a diagnosis. In an emergency, call your local
          emergency number immediately.
        </p>
      </div>

      <div className="flex-1 space-y-4 px-5 py-5">
        {messages.length === 0 && !busy ? (
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Sparkles className="h-4 w-4 text-primary" />
              Try one of these
            </div>
            {STARTERS.map((starter) => (
              <button
                key={starter}
                type="button"
                onClick={() => void send(starter)}
                className="w-full rounded-2xl bg-card px-4 py-3 text-left text-sm text-foreground shadow-card"
              >
                {starter}
              </button>
            ))}
          </div>
        ) : null}

        {messages.map((message, index) =>
          message.role === "user" ? (
            <div key={index} className="flex justify-end">
              <p className="max-w-[85%] rounded-2xl rounded-br-md bg-primary px-4 py-3 text-sm text-primary-foreground">
                {message.content}
              </p>
            </div>
          ) : (
            <div key={index} className="rounded-2xl rounded-bl-md bg-card p-4 shadow-card">
              <AiMarkdown text={message.content} />
            </div>
          ),
        )}

        {busy ? (
          <div className="flex items-center gap-2 rounded-2xl bg-card px-4 py-3 text-sm text-muted-foreground shadow-card">
            <Loader2 className="h-4 w-4 animate-spin text-primary" />
            Reviewing your symptoms…
          </div>
        ) : null}
        <div ref={bottomRef} />
      </div>

      <form
        onSubmit={(event) => {
          event.preventDefault();
          void send(input);
        }}
        className="sticky bottom-20 mx-5 mb-4 flex items-center gap-2 rounded-2xl bg-card p-2 shadow-card"
      >
        <input
          value={input}
          onChange={(event) => setInput(event.target.value)}
          placeholder="Describe your symptoms"
          maxLength={500}
          className="w-full bg-transparent px-2 text-sm outline-none placeholder:text-muted-foreground"
        />
        <VoiceButton onResult={(text) => setInput((prev) => (prev ? `${prev} ${text}` : text))} />
        <Button type="submit" size="icon" className="rounded-full" disabled={busy || !input.trim()}>
          <Send className="h-4 w-4" />
        </Button>
      </form>
    </div>
  );
}

import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import {
  Search,
  Sparkles,
  Stethoscope,
  CalendarPlus,
  BellRing,
  FolderHeart,
  Siren,
  Clock,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/lib/use-session";
import { useI18n } from "@/lib/i18n";
import { VoiceButton } from "@/components/VoiceButton";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/home")({
  head: () => ({
    meta: [
      { title: "Home — MediGuide AI" },
      { name: "description", content: "Your health dashboard: check symptoms, review recent searches and read daily health tips." },
      { property: "og:title", content: "Home — MediGuide AI" },
      { property: "og:description", content: "Check symptoms, review recent searches and read daily health tips." },
    ],
  }),
  component: HomePage,
});

const TIPS = [
  { title: "Drink before you're thirsty", text: "Aim for steady water intake through the day, not one large glass." },
  { title: "Move every hour", text: "Two minutes of walking each hour lowers stiffness and blood sugar spikes." },
  { title: "Sleep window", text: "A consistent bedtime matters more for recovery than total hours alone." },
  { title: "Finish the course", text: "Never stop prescribed antibiotics early, even when you feel better." },
  { title: "Read the label", text: "Check the active ingredient so you don't double up on the same medicine." },
];

const QUICK = [
  { to: "/doctors", icon: Stethoscope, label: "common.doctors" },
  { to: "/appointments", icon: CalendarPlus, label: "common.appointments" },
  { to: "/reminders", icon: BellRing, label: "common.reminders" },
  { to: "/records", icon: FolderHeart, label: "common.records" },
] as const;

function HomePage() {
  const { user } = useSession();
  const { t } = useI18n();
  const navigate = useNavigate();
  const [symptoms, setSymptoms] = useState("");

  const { data: profile } = useQuery({
    queryKey: ["profile", user?.id],
    enabled: Boolean(user),
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("full_name")
        .eq("id", user!.id)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  const { data: recent } = useQuery({
    queryKey: ["recent-checks", user?.id],
    enabled: Boolean(user),
    queryFn: async () => {
      const { data, error } = await supabase
        .from("symptom_checks")
        .select("id, symptoms, created_at")
        .order("created_at", { ascending: false })
        .limit(5);
      if (error) throw error;
      return data;
    },
  });

  const firstName = (profile?.full_name ?? user?.email ?? "there").split(" ")[0];

  function analyze(text: string) {
    const value = text.trim();
    if (!value) return;
    navigate({ to: "/ai", search: { q: value.slice(0, 500) } });
  }

  return (
    <div className="space-y-7">
      <section className="bg-hero-gradient px-5 pb-14 pt-10 text-primary-foreground">
        <p className="text-sm opacity-90">
          {t("home.greeting")}, {firstName}
        </p>
        <h1 className="mt-1 text-2xl font-semibold">{t("home.subtitle")}</h1>
      </section>

      <section className="-mt-12 px-5">
        <form
          onSubmit={(event) => {
            event.preventDefault();
            analyze(symptoms);
          }}
          className="rounded-3xl bg-card p-4 shadow-card"
        >
          <div className="flex items-center gap-2">
            <Search className="h-5 w-5 shrink-0 text-muted-foreground" />
            <input
              value={symptoms}
              onChange={(event) => setSymptoms(event.target.value)}
              placeholder={t("home.search")}
              maxLength={500}
              className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
            />
            <VoiceButton
              onResult={(text) => setSymptoms((prev) => (prev ? `${prev} ${text}` : text))}
            />
          </div>
          <Button type="submit" className="mt-4 w-full rounded-xl" size="lg">
            <Sparkles className="h-4 w-4" />
            {t("home.analyze")}
          </Button>
        </form>
      </section>

      <section className="px-5">
        <h2 className="text-sm font-semibold text-foreground">{t("home.quick")}</h2>
        <div className="mt-3 grid grid-cols-4 gap-3">
          {QUICK.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="flex flex-col items-center gap-2 rounded-2xl bg-card p-3 text-center shadow-card"
            >
              <span className="flex h-10 w-10 items-center justify-center rounded-full bg-accent-soft text-accent-foreground">
                <item.icon className="h-5 w-5" />
              </span>
              <span className="text-[11px] font-medium leading-tight text-foreground">
                {t(item.label)}
              </span>
            </Link>
          ))}
        </div>
      </section>

      {recent && recent.length > 0 ? (
        <section className="px-5">
          <h2 className="text-sm font-semibold text-foreground">{t("home.recent")}</h2>
          <ul className="mt-3 space-y-2">
            {recent.map((item) => (
              <li key={item.id}>
                <button
                  type="button"
                  onClick={() => analyze(item.symptoms)}
                  className="flex w-full items-center gap-3 rounded-2xl bg-card px-4 py-3 text-left shadow-card"
                >
                  <Clock className="h-4 w-4 shrink-0 text-muted-foreground" />
                  <span className="line-clamp-1 text-sm text-foreground">{item.symptoms}</span>
                </button>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      <section>
        <h2 className="px-5 text-sm font-semibold text-foreground">{t("home.tips")}</h2>
        <div className="no-scrollbar mt-3 flex snap-x snap-mandatory gap-3 overflow-x-auto px-5 pb-2">
          {TIPS.map((tip) => (
            <article
              key={tip.title}
              className="w-64 shrink-0 snap-start rounded-2xl bg-mint-gradient p-4 text-accent-foreground shadow-card"
            >
              <h3 className="text-sm font-semibold">{tip.title}</h3>
              <p className="mt-1 text-xs opacity-90">{tip.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="px-5 pb-4">
        <Link
          to="/sos"
          className="flex items-center gap-3 rounded-2xl border border-destructive/30 bg-destructive/10 px-4 py-4"
        >
          <Siren className="h-6 w-6 text-destructive" />
          <div>
            <p className="text-sm font-semibold text-foreground">{t("common.emergency")}</p>
            <p className="text-xs text-muted-foreground">
              Call for help and share your live location instantly.
            </p>
          </div>
        </Link>
      </section>
    </div>
  );
}

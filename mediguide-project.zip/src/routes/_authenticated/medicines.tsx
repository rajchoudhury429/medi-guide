import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Search, Loader2, Pill, ShieldAlert, Baby, HeartPulse, AlertTriangle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/AppShell";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export const Route = createFileRoute("/_authenticated/medicines")({
  head: () => ({
    meta: [
      { title: "Medicine information — MediGuide AI" },
      { name: "description", content: "Look up medicines: uses, dosage guidance from the label, side effects, warnings, age restrictions, pregnancy notes and interactions." },
      { property: "og:title", content: "Medicine information — MediGuide AI" },
      { property: "og:description", content: "Uses, side effects, warnings, age limits, pregnancy notes and drug interactions." },
    ],
  }),
  component: MedicinesPage,
});

type Medicine = {
  id: string;
  name: string;
  generic_name: string | null;
  category: string | null;
  uses: string;
  dosage_guidance: string | null;
  side_effects: string | null;
  warnings: string | null;
  age_restrictions: string | null;
  pregnancy_warning: string | null;
  interactions: string | null;
  prescription_required: boolean;
};

function MedicinesPage() {
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<Medicine | null>(null);

  const { data, isLoading } = useQuery({
    queryKey: ["medicines"],
    queryFn: async () => {
      const { data: rows, error } = await supabase.from("medicines").select("*").order("name");
      if (error) throw error;
      return rows as Medicine[];
    },
  });

  const results = useMemo(() => {
    if (!data) return [];
    const term = query.trim().toLowerCase();
    if (!term) return data;
    return data.filter((medicine) =>
      [medicine.name, medicine.generic_name, medicine.category, medicine.uses]
        .filter(Boolean)
        .some((field) => field!.toLowerCase().includes(term)),
    );
  }, [data, query]);

  return (
    <div>
      <PageHeader title="Medicine information" subtitle="General information from product labels — not a prescription." />

      <div className="mx-5 flex items-center gap-2 rounded-2xl bg-card px-4 py-3 shadow-card">
        <Search className="h-4 w-4 text-muted-foreground" />
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search medicines"
          maxLength={80}
          className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
        />
      </div>

      <ul className="mt-4 space-y-3 px-5 pb-6">
        {isLoading ? (
          <li className="flex justify-center py-8">
            <Loader2 className="h-5 w-5 animate-spin text-primary" />
          </li>
        ) : null}

        {results.map((medicine) => (
          <li key={medicine.id}>
            <button
              type="button"
              onClick={() => setSelected(medicine)}
              className="flex w-full items-center gap-3 rounded-2xl bg-card p-4 text-left shadow-card"
            >
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary-soft text-primary">
                <Pill className="h-5 w-5" />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-sm font-semibold text-foreground">{medicine.name}</span>
                <span className="block truncate text-xs text-muted-foreground">
                  {medicine.generic_name} · {medicine.category}
                </span>
              </span>
              {medicine.prescription_required ? (
                <span className="rounded-full bg-warning-soft px-2 py-1 text-[10px] font-semibold text-warning-foreground">
                  Rx
                </span>
              ) : (
                <span className="rounded-full bg-accent-soft px-2 py-1 text-[10px] font-semibold text-accent-foreground">
                  OTC
                </span>
              )}
            </button>
          </li>
        ))}

        {!isLoading && results.length === 0 ? (
          <li className="rounded-2xl bg-card p-6 text-center text-sm text-muted-foreground shadow-card">
            No medicine matches “{query}”.
          </li>
        ) : null}
      </ul>

      <Dialog open={Boolean(selected)} onOpenChange={(open) => !open && setSelected(null)}>
        <DialogContent className="max-h-[85vh] overflow-y-auto">
          {selected ? (
            <>
              <DialogHeader>
                <DialogTitle>{selected.name}</DialogTitle>
                <DialogDescription>
                  {selected.generic_name} · {selected.category}
                  {selected.prescription_required ? " · Prescription only" : " · Over the counter"}
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-4 text-sm">
                <Section icon={HeartPulse} title="Uses" body={selected.uses} />
                <Section icon={Pill} title="Dosage guidance" body={selected.dosage_guidance} />
                <Section icon={AlertTriangle} title="Side effects" body={selected.side_effects} />
                <Section icon={ShieldAlert} title="Warnings" body={selected.warnings} />
                <Section icon={Baby} title="Age restrictions" body={selected.age_restrictions} />
                <Section icon={Baby} title="Pregnancy" body={selected.pregnancy_warning} />
                <Section icon={ShieldAlert} title="Drug interactions" body={selected.interactions} />
              </div>

              <p className="rounded-xl bg-warning-soft px-3 py-2 text-xs text-warning-foreground">
                Always follow the dosage printed on the product label and ask a pharmacist or doctor
                if you are unsure.
              </p>
            </>
          ) : null}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Section({
  icon: Icon,
  title,
  body,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  body: string | null;
}) {
  if (!body) return null;
  return (
    <div>
      <h3 className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-primary">
        <Icon className="h-3.5 w-3.5" />
        {title}
      </h3>
      <p className="mt-1 text-sm text-foreground">{body}</p>
    </div>
  );
}

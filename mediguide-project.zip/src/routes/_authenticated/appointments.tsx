import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { z } from "zod";
import { CalendarDays, Clock, Loader2, Trash2, Stethoscope } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/lib/use-session";
import { PageHeader } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const searchSchema = z.object({ doctorId: z.string().uuid().optional() });

export const Route = createFileRoute("/_authenticated/appointments")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Appointments — MediGuide AI" },
      { name: "description", content: "Book doctor appointments with date and time slots, then track upcoming and past visits in one place." },
      { property: "og:title", content: "Appointments — MediGuide AI" },
      { property: "og:description", content: "Book and track your doctor appointments." },
    ],
  }),
  component: AppointmentsPage,
});

const SLOTS = ["09:00", "10:00", "11:00", "12:00", "15:00", "16:00", "17:00", "18:00"];

const formSchema = z.object({
  doctorId: z.string().uuid({ message: "Choose a doctor" }),
  date: z.string().min(1, "Choose a date"),
  time: z.string().min(1, "Choose a time slot"),
  reason: z.string().trim().max(300).optional(),
});

function AppointmentsPage() {
  const { doctorId } = Route.useSearch();
  const { user } = useSession();
  const queryClient = useQueryClient();
  const today = new Date().toISOString().slice(0, 10);

  const [selectedDoctor, setSelectedDoctor] = useState(doctorId ?? "");
  const [date, setDate] = useState(today);
  const [time, setTime] = useState("");
  const [reason, setReason] = useState("");

  useEffect(() => {
    if (doctorId) setSelectedDoctor(doctorId);
  }, [doctorId]);

  const { data: doctors } = useQuery({
    queryKey: ["doctors"],
    queryFn: async () => {
      const { data, error } = await supabase.from("doctors").select("*").order("name");
      if (error) throw error;
      return data;
    },
  });

  const { data: appointments, isLoading } = useQuery({
    queryKey: ["appointments", user?.id],
    enabled: Boolean(user),
    queryFn: async () => {
      const { data, error } = await supabase
        .from("appointments")
        .select("*")
        .order("appointment_date", { ascending: true });
      if (error) throw error;
      return data;
    },
  });

  const book = useMutation({
    mutationFn: async () => {
      const parsed = formSchema.safeParse({ doctorId: selectedDoctor, date, time, reason });
      if (!parsed.success) throw new Error(parsed.error.issues[0].message);
      const doctor = doctors?.find((item) => item.id === parsed.data.doctorId);
      if (!doctor) throw new Error("Doctor not found");

      const { error } = await supabase.from("appointments").insert({
        user_id: user!.id,
        doctor_id: doctor.id,
        doctor_name: doctor.name,
        specialty: doctor.specialty,
        appointment_date: parsed.data.date,
        appointment_time: parsed.data.time,
        reason: parsed.data.reason || null,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Appointment booked");
      setTime("");
      setReason("");
      queryClient.invalidateQueries({ queryKey: ["appointments", user?.id] });
    },
    onError: (error) => toast.error(error.message),
  });

  const cancel = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("appointments")
        .update({ status: "cancelled" })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Appointment cancelled");
      queryClient.invalidateQueries({ queryKey: ["appointments", user?.id] });
    },
    onError: (error) => toast.error(error.message),
  });

  const upcoming = (appointments ?? []).filter(
    (item) => item.appointment_date >= today && item.status !== "cancelled",
  );
  const past = (appointments ?? []).filter(
    (item) => item.appointment_date < today || item.status === "cancelled",
  );

  return (
    <div>
      <PageHeader title="Appointments" subtitle="Book a visit and keep track of your schedule." />

      <section className="mx-5 space-y-4 rounded-2xl bg-card p-4 shadow-card">
        <h2 className="text-sm font-semibold text-foreground">Book a new appointment</h2>

        <label className="block text-xs font-medium text-muted-foreground">
          Doctor
          <select
            value={selectedDoctor}
            onChange={(event) => setSelectedDoctor(event.target.value)}
            className="mt-1 w-full rounded-xl border border-input bg-background px-3 py-2 text-sm text-foreground"
          >
            <option value="">Select a doctor</option>
            {doctors?.map((doctor) => (
              <option key={doctor.id} value={doctor.id}>
                {doctor.name} — {doctor.specialty}
              </option>
            ))}
          </select>
        </label>

        <label className="block text-xs font-medium text-muted-foreground">
          Date
          <input
            type="date"
            value={date}
            min={today}
            onChange={(event) => setDate(event.target.value)}
            className="mt-1 w-full rounded-xl border border-input bg-background px-3 py-2 text-sm text-foreground"
          />
        </label>

        <div>
          <p className="text-xs font-medium text-muted-foreground">Time slot</p>
          <div className="mt-2 grid grid-cols-4 gap-2">
            {SLOTS.map((slot) => (
              <button
                key={slot}
                type="button"
                onClick={() => setTime(slot)}
                className={cn(
                  "rounded-xl px-2 py-2 text-xs font-medium transition-colors",
                  time === slot
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-secondary-foreground",
                )}
              >
                {slot}
              </button>
            ))}
          </div>
        </div>

        <label className="block text-xs font-medium text-muted-foreground">
          Reason (optional)
          <textarea
            value={reason}
            onChange={(event) => setReason(event.target.value)}
            maxLength={300}
            rows={2}
            className="mt-1 w-full rounded-xl border border-input bg-background px-3 py-2 text-sm text-foreground"
            placeholder="Follow-up on chest pain"
          />
        </label>

        <Button className="w-full" onClick={() => book.mutate()} disabled={book.isPending}>
          {book.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <CalendarDays className="h-4 w-4" />}
          Confirm booking
        </Button>
      </section>

      <section className="mt-6 px-5">
        <h2 className="text-sm font-semibold text-foreground">Upcoming</h2>
        {isLoading ? (
          <div className="flex justify-center py-6">
            <Loader2 className="h-5 w-5 animate-spin text-primary" />
          </div>
        ) : null}
        {!isLoading && upcoming.length === 0 ? (
          <p className="mt-2 text-xs text-muted-foreground">No upcoming appointments.</p>
        ) : null}
        <ul className="mt-3 space-y-3">
          {upcoming.map((item) => (
            <li key={item.id} className="rounded-2xl bg-card p-4 shadow-card">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-sm font-semibold text-foreground">{item.doctor_name}</p>
                  <p className="flex items-center gap-1 text-xs text-primary">
                    <Stethoscope className="h-3.5 w-3.5" />
                    {item.specialty}
                  </p>
                  <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
                    <Clock className="h-3.5 w-3.5" />
                    {item.appointment_date} at {item.appointment_time?.slice(0, 5)}
                  </p>
                  {item.reason ? (
                    <p className="mt-1 text-xs text-muted-foreground">{item.reason}</p>
                  ) : null}
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  aria-label="Cancel appointment"
                  onClick={() => cancel.mutate(item.id)}
                >
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            </li>
          ))}
        </ul>
      </section>

      {past.length > 0 ? (
        <section className="mt-6 px-5 pb-6">
          <h2 className="text-sm font-semibold text-foreground">Past & cancelled</h2>
          <ul className="mt-3 space-y-2">
            {past.map((item) => (
              <li
                key={item.id}
                className="flex items-center justify-between rounded-2xl bg-card px-4 py-3 text-xs shadow-card"
              >
                <span className="text-foreground">
                  {item.doctor_name} · {item.appointment_date}
                </span>
                <span className="capitalize text-muted-foreground">{item.status}</span>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </div>
  );
}

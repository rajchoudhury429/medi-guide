import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Search, Star, MapPin, Loader2, CalendarPlus, Phone } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/doctors")({
  head: () => ({
    meta: [
      { title: "Find a doctor — MediGuide AI" },
      { name: "description", content: "Search doctors by specialty — cardiologist, neurologist, dermatologist, dentist, pediatrician, orthopedic and ENT — with experience, rating and clinic." },
      { property: "og:title", content: "Find a doctor — MediGuide AI" },
      { property: "og:description", content: "Browse specialists with experience, ratings and clinic locations, then book an appointment." },
    ],
  }),
  component: DoctorsPage,
});

const SPECIALTIES = [
  "All",
  "Cardiologist",
  "Neurologist",
  "Dermatologist",
  "Dentist",
  "Pediatrician",
  "Orthopedic",
  "ENT",
];

function DoctorsPage() {
  const [specialty, setSpecialty] = useState("All");
  const [query, setQuery] = useState("");

  const { data, isLoading } = useQuery({
    queryKey: ["doctors"],
    queryFn: async () => {
      const { data: rows, error } = await supabase
        .from("doctors")
        .select("*")
        .order("rating", { ascending: false });
      if (error) throw error;
      return rows;
    },
  });

  const doctors = useMemo(() => {
    if (!data) return [];
    const term = query.trim().toLowerCase();
    return data.filter((doctor) => {
      const matchSpecialty = specialty === "All" || doctor.specialty === specialty;
      const matchQuery =
        !term ||
        doctor.name.toLowerCase().includes(term) ||
        (doctor.clinic_name ?? "").toLowerCase().includes(term) ||
        (doctor.city ?? "").toLowerCase().includes(term);
      return matchSpecialty && matchQuery;
    });
  }, [data, specialty, query]);

  return (
    <div>
      <PageHeader title="Find a doctor" subtitle="Browse specialists and book an appointment." />

      <div className="mx-5 flex items-center gap-2 rounded-2xl bg-card px-4 py-3 shadow-card">
        <Search className="h-4 w-4 text-muted-foreground" />
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search by name, clinic or city"
          maxLength={80}
          className="w-full bg-transparent text-sm outline-none placeholder:text-muted-foreground"
        />
      </div>

      <div className="no-scrollbar mt-4 flex gap-2 overflow-x-auto px-5">
        {SPECIALTIES.map((item) => (
          <button
            key={item}
            type="button"
            onClick={() => setSpecialty(item)}
            className={cn(
              "shrink-0 rounded-full px-4 py-2 text-sm font-medium transition-colors",
              specialty === item
                ? "bg-primary text-primary-foreground"
                : "bg-card text-muted-foreground shadow-card",
            )}
          >
            {item}
          </button>
        ))}
      </div>

      <ul className="mt-4 space-y-3 px-5 pb-6">
        {isLoading ? (
          <li className="flex justify-center py-8">
            <Loader2 className="h-5 w-5 animate-spin text-primary" />
          </li>
        ) : null}

        {doctors.map((doctor) => (
          <li key={doctor.id} className="rounded-2xl bg-card p-4 shadow-card">
            <div className="flex items-start gap-3">
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary-soft text-base font-semibold text-primary">
                {doctor.name.replace("Dr. ", "").charAt(0)}
              </span>
              <div className="min-w-0 flex-1">
                <h2 className="text-sm font-semibold text-foreground">{doctor.name}</h2>
                <p className="text-xs font-medium text-primary">{doctor.specialty}</p>
                <p className="mt-1 text-xs text-muted-foreground">{doctor.qualification}</p>
                <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
                  <MapPin className="h-3.5 w-3.5" />
                  {doctor.clinic_name}, {doctor.city}
                </p>
                <div className="mt-2 flex flex-wrap gap-2 text-xs">
                  <span className="flex items-center gap-1 rounded-full bg-secondary px-2 py-1 text-secondary-foreground">
                    <Star className="h-3 w-3 fill-current text-warning" />
                    {Number(doctor.rating).toFixed(1)}
                  </span>
                  <span className="rounded-full bg-secondary px-2 py-1 text-secondary-foreground">
                    {doctor.experience_years} yrs exp
                  </span>
                  {doctor.consultation_fee ? (
                    <span className="rounded-full bg-accent-soft px-2 py-1 text-accent-foreground">
                      ₹{doctor.consultation_fee}
                    </span>
                  ) : null}
                </div>
              </div>
            </div>

            {doctor.bio ? <p className="mt-3 text-xs text-muted-foreground">{doctor.bio}</p> : null}

            <div className="mt-4 grid grid-cols-2 gap-2">
              <Button asChild variant="outline" size="sm">
                <a href={`tel:${doctor.phone ?? ""}`}>
                  <Phone className="h-4 w-4" />
                  Call clinic
                </a>
              </Button>
              <Button asChild size="sm">
                <Link to="/appointments" search={{ doctorId: doctor.id }}>
                  <CalendarPlus className="h-4 w-4" />
                  Book
                </Link>
              </Button>
            </div>
          </li>
        ))}

        {!isLoading && doctors.length === 0 ? (
          <li className="rounded-2xl bg-card p-6 text-center text-sm text-muted-foreground shadow-card">
            No doctors match your search.
          </li>
        ) : null}
      </ul>
    </div>
  );
}

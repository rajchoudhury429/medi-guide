import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { z } from "zod";
import {
  BellRing,
  CalendarDays,
  FolderHeart,
  Languages,
  LogOut,
  Loader2,
  Moon,
  Save,
  Siren,
  Stethoscope,
  Sun,
} from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/lib/use-session";
import { useI18n, LANGUAGES, type LanguageCode } from "@/lib/i18n";
import { applyTheme, getStoredTheme, type ThemeMode } from "@/lib/theme";
import { PageHeader } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";

export const Route = createFileRoute("/_authenticated/profile")({
  head: () => ({
    meta: [
      { title: "Profile & settings — MediGuide AI" },
      { name: "description", content: "Manage your health profile, blood group, allergies and chronic conditions, plus language, theme and notification settings." },
      { property: "og:title", content: "Profile & settings — MediGuide AI" },
      { property: "og:description", content: "Health profile, language, theme and notification preferences." },
    ],
  }),
  component: ProfilePage,
});

const BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];

const schema = z.object({
  full_name: z.string().trim().max(80).optional(),
  phone: z.string().trim().max(25).optional(),
  age: z.number().int().min(0).max(120).nullable(),
  blood_group: z.string().max(5).nullable(),
  height_cm: z.number().min(0).max(280).nullable(),
  weight_kg: z.number().min(0).max(500).nullable(),
  allergies: z.string().trim().max(300).optional(),
  chronic_conditions: z.string().trim().max(300).optional(),
});

const LINKS = [
  { to: "/doctors", icon: Stethoscope, label: "Doctors" },
  { to: "/appointments", icon: CalendarDays, label: "Appointments" },
  { to: "/reminders", icon: BellRing, label: "Reminders" },
  { to: "/records", icon: FolderHeart, label: "Health records" },
  { to: "/sos", icon: Siren, label: "Emergency SOS" },
] as const;

function ProfilePage() {
  const { user } = useSession();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { language, setLanguage, t } = useI18n();
  const [theme, setTheme] = useState<ThemeMode>("light");

  const [form, setForm] = useState({
    full_name: "",
    phone: "",
    age: "",
    blood_group: "",
    height_cm: "",
    weight_kg: "",
    allergies: "",
    chronic_conditions: "",
    notifications_enabled: true,
    share_location: true,
  });

  useEffect(() => {
    setTheme(getStoredTheme());
  }, []);

  const { data: profile, isLoading } = useQuery({
    queryKey: ["profile", user?.id],
    enabled: Boolean(user),
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user!.id)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  useEffect(() => {
    if (!profile) return;
    setForm({
      full_name: profile.full_name ?? "",
      phone: profile.phone ?? "",
      age: profile.age?.toString() ?? "",
      blood_group: profile.blood_group ?? "",
      height_cm: profile.height_cm?.toString() ?? "",
      weight_kg: profile.weight_kg?.toString() ?? "",
      allergies: profile.allergies ?? "",
      chronic_conditions: profile.chronic_conditions ?? "",
      notifications_enabled: profile.notifications_enabled,
      share_location: profile.share_location,
    });
  }, [profile]);

  const save = useMutation({
    mutationFn: async () => {
      const parsed = schema.safeParse({
        full_name: form.full_name,
        phone: form.phone,
        age: form.age ? Number(form.age) : null,
        blood_group: form.blood_group || null,
        height_cm: form.height_cm ? Number(form.height_cm) : null,
        weight_kg: form.weight_kg ? Number(form.weight_kg) : null,
        allergies: form.allergies,
        chronic_conditions: form.chronic_conditions,
      });
      if (!parsed.success) throw new Error(parsed.error.issues[0].message);

      const { error } = await supabase
        .from("profiles")
        .update({
          ...parsed.data,
          full_name: parsed.data.full_name || null,
          phone: parsed.data.phone || null,
          allergies: parsed.data.allergies || null,
          chronic_conditions: parsed.data.chronic_conditions || null,
          notifications_enabled: form.notifications_enabled,
          share_location: form.share_location,
          language,
          theme,
        })
        .eq("id", user!.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Profile updated");
      queryClient.invalidateQueries({ queryKey: ["profile", user?.id] });
    },
    onError: (error) => toast.error(error.message),
  });

  function toggleTheme() {
    const next: ThemeMode = theme === "light" ? "dark" : "light";
    setTheme(next);
    applyTheme(next);
  }

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  const field = (key: keyof typeof form) => ({
    value: form[key] as string,
    onChange: (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
      setForm((prev) => ({ ...prev, [key]: event.target.value })),
  });

  return (
    <div className="pb-6">
      <PageHeader title="Profile" subtitle={user?.email ?? undefined} />

      {isLoading ? (
        <div className="flex justify-center py-8">
          <Loader2 className="h-5 w-5 animate-spin text-primary" />
        </div>
      ) : null}

      <section className="mx-5 space-y-3 rounded-2xl bg-card p-4 shadow-card">
        <h2 className="text-sm font-semibold text-foreground">Health profile</h2>
        <input
          {...field("full_name")}
          placeholder="Full name"
          maxLength={80}
          className="w-full rounded-xl border border-input bg-background px-3 py-2 text-sm"
        />
        <input
          {...field("phone")}
          placeholder="Phone"
          inputMode="tel"
          maxLength={25}
          className="w-full rounded-xl border border-input bg-background px-3 py-2 text-sm"
        />
        <div className="grid grid-cols-3 gap-2">
          <input
            {...field("age")}
            placeholder="Age"
            inputMode="numeric"
            className="rounded-xl border border-input bg-background px-3 py-2 text-sm"
          />
          <input
            {...field("height_cm")}
            placeholder="Height cm"
            inputMode="numeric"
            className="rounded-xl border border-input bg-background px-3 py-2 text-sm"
          />
          <input
            {...field("weight_kg")}
            placeholder="Weight kg"
            inputMode="numeric"
            className="rounded-xl border border-input bg-background px-3 py-2 text-sm"
          />
        </div>
        <select
          value={form.blood_group}
          onChange={(event) => setForm((prev) => ({ ...prev, blood_group: event.target.value }))}
          className="w-full rounded-xl border border-input bg-background px-3 py-2 text-sm"
        >
          <option value="">Blood group</option>
          {BLOOD_GROUPS.map((group) => (
            <option key={group} value={group}>
              {group}
            </option>
          ))}
        </select>
        <textarea
          {...field("allergies")}
          placeholder="Allergies"
          rows={2}
          maxLength={300}
          className="w-full rounded-xl border border-input bg-background px-3 py-2 text-sm"
        />
        <textarea
          {...field("chronic_conditions")}
          placeholder="Chronic conditions"
          rows={2}
          maxLength={300}
          className="w-full rounded-xl border border-input bg-background px-3 py-2 text-sm"
        />
        <Button className="w-full" onClick={() => save.mutate()} disabled={save.isPending}>
          {save.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          Save changes
        </Button>
      </section>

      <section className="mx-5 mt-4 space-y-3 rounded-2xl bg-card p-4 shadow-card">
        <h2 className="text-sm font-semibold text-foreground">{t("common.settings")}</h2>

        <label className="flex items-center justify-between gap-3 text-sm text-foreground">
          <span className="flex items-center gap-2">
            <Languages className="h-4 w-4 text-primary" />
            Language
          </span>
          <select
            value={language}
            onChange={(event) => setLanguage(event.target.value as LanguageCode)}
            className="rounded-xl border border-input bg-background px-3 py-2 text-sm"
          >
            {LANGUAGES.map((item) => (
              <option key={item.code} value={item.code}>
                {item.label}
              </option>
            ))}
          </select>
        </label>

        <div className="flex items-center justify-between gap-3 text-sm text-foreground">
          <span className="flex items-center gap-2">
            {theme === "dark" ? (
              <Moon className="h-4 w-4 text-primary" />
            ) : (
              <Sun className="h-4 w-4 text-primary" />
            )}
            Dark mode
          </span>
          <Switch checked={theme === "dark"} onCheckedChange={toggleTheme} aria-label="Dark mode" />
        </div>

        <div className="flex items-center justify-between gap-3 text-sm text-foreground">
          <span className="flex items-center gap-2">
            <BellRing className="h-4 w-4 text-primary" />
            Reminder notifications
          </span>
          <Switch
            checked={form.notifications_enabled}
            onCheckedChange={(checked) =>
              setForm((prev) => ({ ...prev, notifications_enabled: checked }))
            }
            aria-label="Notifications"
          />
        </div>

        <div className="flex items-center justify-between gap-3 text-sm text-foreground">
          <span className="flex items-center gap-2">
            <Siren className="h-4 w-4 text-primary" />
            Share location in SOS
          </span>
          <Switch
            checked={form.share_location}
            onCheckedChange={(checked) => setForm((prev) => ({ ...prev, share_location: checked }))}
            aria-label="Share location"
          />
        </div>
      </section>

      <section className="mx-5 mt-4 overflow-hidden rounded-2xl bg-card shadow-card">
        {LINKS.map((link) => (
          <Link
            key={link.to}
            to={link.to}
            className="flex items-center gap-3 border-b border-border px-4 py-3 text-sm text-foreground last:border-b-0"
          >
            <link.icon className="h-4 w-4 text-primary" />
            {link.label}
          </Link>
        ))}
      </section>

      <div className="mx-5 mt-4">
        <Button variant="outline" className="w-full" onClick={signOut}>
          <LogOut className="h-4 w-4" />
          Sign out
        </Button>
      </div>
    </div>
  );
}

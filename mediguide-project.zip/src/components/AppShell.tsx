import type { ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Home, Sparkles, Hospital, Pill, User, Siren } from "lucide-react";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/i18n";

const NAV = [
  { to: "/home", icon: Home, key: "nav.home" },
  { to: "/ai", icon: Sparkles, key: "nav.ai" },
  { to: "/hospitals", icon: Hospital, key: "nav.hospitals" },
  { to: "/medicines", icon: Pill, key: "nav.medicines" },
  { to: "/profile", icon: User, key: "nav.profile" },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const { t } = useI18n();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-lg flex-col bg-background">
      <main className="flex-1 pb-28">{children}</main>

      <Link
        to="/sos"
        aria-label={t("common.emergency")}
        className="fixed bottom-24 left-1/2 z-20 -translate-x-1/2 sm:left-auto sm:right-[max(1rem,calc(50%-15rem))] sm:translate-x-0"
      >
        <span className="flex items-center gap-2 rounded-full bg-destructive px-5 py-3 text-sm font-semibold text-destructive-foreground shadow-card transition-transform active:scale-95">
          <Siren className="h-4 w-4" />
          SOS
        </span>
      </Link>

      <nav className="fixed bottom-0 left-1/2 z-30 w-full max-w-lg -translate-x-1/2 border-t border-border bg-card/95 pb-[env(safe-area-inset-bottom)] shadow-float backdrop-blur">
        <ul className="grid grid-cols-5">
          {NAV.map((item) => {
            const active = pathname.startsWith(item.to);
            const Icon = item.icon;
            return (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className={cn(
                    "flex flex-col items-center gap-1 py-3 text-[11px] font-medium transition-colors",
                    active ? "text-primary" : "text-muted-foreground",
                  )}
                >
                  <span
                    className={cn(
                      "flex h-8 w-12 items-center justify-center rounded-full transition-colors",
                      active && "bg-primary-soft",
                    )}
                  >
                    <Icon className="h-5 w-5" />
                  </span>
                  {t(item.key)}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}

export function PageHeader({
  title,
  subtitle,
  action,
}: {
  title: string;
  subtitle?: string;
  action?: ReactNode;
}) {
  return (
    <header className="flex items-start justify-between gap-4 px-5 pb-4 pt-8">
      <div>
        <h1 className="text-2xl font-semibold text-foreground">{title}</h1>
        {subtitle ? <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p> : null}
      </div>
      {action}
    </header>
  );
}

import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const ChatInput = z.object({
  messages: z
    .array(
      z.object({
        role: z.enum(["user", "assistant"]),
        content: z.string().min(1).max(4000),
      }),
    )
    .min(1)
    .max(30),
});

const SYSTEM_PROMPT = `You are MediGuide AI, a careful health information assistant inside a consumer health app.

You are NOT a doctor and you never diagnose. Always be calm, plain-spoken and structured.

Behaviour:
- If the user's description is vague or missing key detail (duration, severity, age, temperature, other symptoms, existing conditions, medicines taken), ask at most 2 short follow-up questions FIRST, and nothing else.
- Once you have enough detail, reply using exactly these markdown headings, in this order:

## Possible conditions
Informational only — 2 to 4 possibilities, each one line, each with a likelihood word (common / less common / rare). Start this section with the line: *This is general information, not a diagnosis.*

## Self-care advice
3 to 5 short bullets.

## Common over-the-counter options
General information about typical OTC medicines people use for this, with the reminder to follow the dosage on the product label. Include key precautions and common side effects. Never give a personalised prescription or an exact personal dose.

## Emergency warning signs
Bullets describing symptoms that need immediate medical attention.

## When to see a doctor
2 to 3 bullets.

Rules:
- If anything the user describes sounds like a medical emergency (chest pain, trouble breathing, stroke signs, severe bleeding, suicidal thoughts, unresponsiveness), lead with a clear line telling them to call emergency services now.
- Keep the whole answer under 350 words.
- Never claim certainty. Never name prescription-only drugs as a recommendation.`;

export const askSymptomAI = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => ChatInput.parse(input))
  .handler(async ({ data }) => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("AI is not configured yet.");

    const { generateText } = await import("ai");
    const { createLovableAiGatewayProvider } = await import("./ai-gateway.server");
    const gateway = createLovableAiGatewayProvider(apiKey);

    try {
      const result = await generateText({
        model: gateway("google/gemini-3.6-flash"),
        system: SYSTEM_PROMPT,
        messages: data.messages,
      });
      return { text: result.text };
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      if (message.includes("429")) {
        throw new Error("The assistant is busy right now. Please try again in a moment.");
      }
      if (message.includes("402")) {
        throw new Error("AI credits are exhausted. Please top up to keep using the symptom checker.");
      }
      throw new Error("The assistant could not respond. Please try again.");
    }
  });
